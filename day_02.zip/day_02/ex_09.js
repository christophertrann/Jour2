displayThisText('the variable value is ' + (input_var) + '<br/>' + 'its type is ' +
(typeof imput_var))

if (input_var == '42'){

displayThisText('It is the meaning of life.')}