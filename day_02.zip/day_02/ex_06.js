let bananas = 1
if (bananas === 0){
displayThisText('Oh no there is no banana')
}
if (bananas > 0){
displayThisText('Yummy!')
}
if (bananas < 0){
displayThisText('Do I owe you bananas ?')
}