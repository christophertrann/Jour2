if (breadCount >= 2 )
if (hamCount >= 1 ){
displayThisText('I can make a ham sandwich!')
}
if (breadCount >= 2 )
if (tunaCount >= 1 ){
displayThisText('I can make a tuna sandwich!')
}
if (breadCount >= 2 )
if (hamCount >= 1 )
if (tunaCount >= 1 ){
displayThisText('I can make a royal sandwich!')}
else
{
displayThisText('Id rather be fasting tonight..')
}