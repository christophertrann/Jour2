let greeting=("Hello World")
displayThisText(greeting)