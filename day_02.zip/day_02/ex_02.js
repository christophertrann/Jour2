let integer = "true"
let float = "forty two"
let string = "42"
let bool = "null"
let this_is_null = "42.42"
displayThisText(integer)
displayThisText(float)
displayThisText(string)
displayThisText(bool)
displayThisText(this_is_null)