if (password === 'forty-two' )
{
displayThisText('Success')}
else
{
displayThisText('wrong passeword')}